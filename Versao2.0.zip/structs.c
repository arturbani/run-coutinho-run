#include <string.h>
#include <stdio.h>
#include "Bibliotecas/structs.h"
// #include "Bibliotecas/library.h"
// #include "library.h"

// typedef struct Quadrado{
//   //Atributos Base: Servem para qualquer Quadrado:
//     int visivel;
//     char nome [30];
//     float x;
//     float y;
//     float tx;
//     float ty;
//     float r,g,b; //Cores
//     struct Quadrado *proxquadrado;

//   //Atributos Específicos: Para cada 'subclasse': (Obs:Cada subclasse possui sua propria library)
//   //Moedas:
//     int isMoeda; //Identidade (se é moeda ou não)

//   //Inimigos:
//     int isInimigo; //Identidade

//   //PowerUp (Não Implementado):
//     // int isPowerUpInvencibilidade //Exemplo:


// }quadrado;

//Funções Base:
//Objeto Manipulado + Novo Nome
void nomeQuadrado(quadrado*Objeto, char* Novo_Nome){
  strcpy(Objeto->nome,Novo_Nome);
}


//Objeto Manipulado + Nova Coord X e Nova Coord Y
void posQuadrado(quadrado* Objeto ,float Novo_X,float Novo_Y ){
    Objeto->x = Novo_X;
    Objeto->y = Novo_Y;
}
//Objeto Manipulado + Novo Tamanho no Eixo X(Tx) e Novo Tamanho no Eixo Y (Ty)
void tamQuadrado(quadrado* Objeto,float Novo_Tx, float Novo_Ty){
    Objeto->tx = Novo_Tx;
    Objeto->ty = Novo_Ty;

}

//Objeto Manipulado + cores R,G,B
void corQuadrado(quadrado *Objeto,float r,float g,float b){
  Objeto->r = r;
  Objeto->g = g;
  Objeto->b = b;

}

//Realiza um Link entre dois Objetos(Liga Dois Quadrados formando uma Lista Encadeada)
void linkQuadrado(quadrado *Objeto1, quadrado*Objeto2){
  Objeto1->proxquadrado = Objeto2;


}
//Acaba o Link(Fim_da_Lista_Encadeada) entre os Quadrados
void linkEnd(quadrado *Objeto1){
  Objeto1->proxquadrado = NULL;
}


///////////////////////////////////////////////////////////////
//Funções Moeda:

void initAsMoeda(quadrado *a){
//Atribuir Classe: Quadrado como Subclasse: Moeda
  a->isMoeda = 1;
//Desatribuir das demais Classes: (Ou é moeda ou inimigo, não pode ser os 2)
  a->isInimigo = 0;

  a->visivel = 1; //A moeda vai estar de inicio visivel pro jogador

}

//Funcao para colisao da moeda
void colisaoMoeda(quadrado *a,int *score){
   // a->visivel = 0;
   a->x = -30;
   
  // *score+=200;
  // printf("PegueiMoeda:%i\n",*score); 
//Highscore ++

  //Reset da colisão dentro da main
}


///////////////////////////////////////////////////////////////////
//Inimigo:

//Inicialização como Inimigo
void initAsInimigo(quadrado *a){
//Atribuição Classe: Quadrado Atribuir Subclasse: Inimigo
  a->isInimigo = 1;
//Desatribuir demais Classes:
  a->isMoeda = 0;

  a->visivel = 1; //Inimigo sempre visivel


}



//O efeito da colisão com Inimigo
void colisaoInimigo(quadrado *a){
  // GameOver();


}


