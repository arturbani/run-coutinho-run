
void verificarLiberarMovimento(int *theEnd,int* MovimentarOn);

void verificaColisao(quadrado *a, quadrado* Jogador,int* ColisaoOn);

// void verificaPosicao(quadrado *Objeto,int INICIO_DO_MUNDO,int Max_Random_Spawn,int Minimum_Distance_Spawn,int groundlevel, quadrado *Primeiro_da_Lista);
