
void texto(void* font, char* s, float x, float y);

void telaFim();

//Depois Mudar de Lugar(Temporário);
void GameOver(int* MovimentarOn,int *theEnd);