//Funçoes estão no structs.c

//Inicialização como Inimigo
void initAsInimigo(quadrado *a);

//O efeito da colisão com Inimigo
void colisaoInimigo(quadrado *a);
