
//Essa função retorna a posição X do objeto mais distante( Mais a Direita do jogador), util para as funções Respawn
//Retorna somente a posição do inimigo
// float objMaisDistante(quadrado *Primeiro_da_Lista);

//Respawn do Objeto
// void eventoRespawn(quadrado *Objeto,int Max_Random_Spawn,int Minimum_Distance_Spawn,int groundlevel,quadrado *Primeiro_da_Lista);
