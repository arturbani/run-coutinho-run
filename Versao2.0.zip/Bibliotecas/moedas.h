

//Inicializando como Moeda
//Funções estão no structs.c

void initAsMoeda(quadrado *a);

//Funcao para colisao da moeda
void colisaoMoeda(quadrado *a,int *score);


