
typedef struct Quadrado{
  //Atributos Base: Servem para qualquer Quadrado:
    int visivel;
    char nome [30];
    float x;
    float y;
    float tx;
    float ty;
    float r,g,b; //Cores
    struct Quadrado *proxquadrado;

  //Atributos Específicos: Para cada 'subclasse': (Obs:Cada subclasse possui sua propria library)
  //Moedas:
    int isMoeda; //Identidade (se é moeda ou não)

  //Inimigos:
    int isInimigo; //Identidade

  //PowerUp (Não Implementado):
    // int isPowerUpInvencibilidade //Exemplo:


}quadrado;

//Objeto Manipulado + Novo Nome
void nomeQuadrado(quadrado*Objeto, char* Novo_Nome);
//Objeto Manipulado + Nova Coord X e Nova Coord Y
void posQuadrado(quadrado* Objeto ,float Novo_X,float Novo_Y );
//Objeto Manipulado + Novo Tamanho no Eixo X(Tx) e Novo Tamanho no Eixo Y (Ty)
void tamQuadrado(quadrado* Objeto,float Novo_Tx, float Novo_Ty);
//Objeto Manipulado + cores R,G,B
void corQuadrado(quadrado *Objeto,float r,float g,float b);
//Realiza um Link entre dois Objetos(Liga Dois Quadrados formando uma Lista Encadeada)
void linkQuadrado(quadrado *Objeto1, quadrado*Objeto2);
//Acaba o Link(Fim_da_Lista_Encadeada) entre os Quadrados
void linkEnd(quadrado *Objeto1);