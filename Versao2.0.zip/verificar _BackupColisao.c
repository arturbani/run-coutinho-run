#include "Bibliotecas/structs.h"
#include "Bibliotecas/respawn.h"

//Funções para o Desenvolvimento do Jogo:
//Mudar o nome dessa porra depois
void verificarLiberarMovimento(int *theEnd,int* MovimentarOn){
    if(*theEnd == 0){    //Nao liberar movimento enquanto em tela de morte (TESTE) (DESATIVADO)
        if(*MovimentarOn == 0)
            *MovimentarOn = 1;
        else
            *MovimentarOn = 0;
    }
}


void verificaColisao(quadrado *a, quadrado* Jogador,int *ColisaoOn){

    //Eixo X e Eixo Y, respectivamente
    if( Jogador->x+Jogador->tx > a->x && Jogador->x<= a->x+a->tx)
    if( Jogador->y+Jogador->ty>= a->x && a->y+a->ty>= Jogador->y)
        *ColisaoOn = 1;


}



// //Reposicionar o objeto caso ele tenha saido de Cena (para os quadrados "inimigos"),
// //Para um mundo começando no eixo X.
// void verificaPosicao(quadrado *Objeto,int INICIO_DO_MUNDO,int Max_Random_Spawn,int Minimum_Distance_Spawn,int groundlevel,quadrado *Primeiro_da_Lista){
// //Quando o quadrado percorrer até o final do mundo, (tendo percorrido todo seu tamanho);
//   if( Objeto->x < -(Objeto->tx)+INICIO_DO_MUNDO )
//     eventoRespawn(Objeto,Max_Random_Spawn,Minimum_Distance_Spawn,groundlevel,Primeiro_da_Lista);
//     Objeto->visivel = 1;

// }

