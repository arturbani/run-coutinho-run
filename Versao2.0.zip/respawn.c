// #include "Bibliotecas/structs.h"
// #include <stdio.h>
// #include <time.h>
// #include <stdlib.h>

// //Essa função retorna a posição X do objeto mais distante( Mais a Direita do jogador), util para as funções Respawn
// //Retorna somente a posição do inimigo
// float objMaisDistante(quadrado *Primeiro_da_Lista){
//   float n = Primeiro_da_Lista-> x;
//   quadrado *i = &(*Primeiro_da_Lista);
//   do{
//     if(i->isInimigo)
//         if( i->x > n)
//         n = i->x;
//     i = i->proxquadrado;
//   }
//   while ( (i) != NULL);


//   return n;
// }

// //Respawn do Objeto
// void eventoRespawn(quadrado *Objeto,int Max_Random_Spawn,int Minimum_Distance_Spawn,int groundlevel,quadrado *Primeiro_da_Lista){

//   //Primeiramente: Descobre a posição do objeto mais distante;
//   float posMaior = objMaisDistante(Primeiro_da_Lista);

//   //Atribui um valor da variação para ser somado à posição;
//   float valorVariacao = rand()%Max_Random_Spawn+Minimum_Distance_Spawn;


//   if(Objeto->isInimigo){
//    //Determina a nova Posição do Quadrado;
//       posQuadrado(Objeto, posMaior+valorVariacao ,groundlevel+0);

//   }
//   else if(Objeto->isMoeda){
//       posQuadrado(Objeto,posMaior+975+valorVariacao,groundlevel);
//   }

//   printf("Respawnou:%s\n",Objeto->nome); //debug
// }
