
#include<time.h>
#include<stdlib.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <SOIL/SOIL.h>
#include <stdio.h>

struct coordenadas {
    float x, y, z;
};

 struct coordenadas vet;     //vetor
 struct coordenadas pt;      //ponto
 struct coordenadas d;       //dimensão

 struct hitbox {
   int x;
   int y;
   int xp;
   int yp;
   int c=0;
   float z;
   int altura=100;
   int largura;
     void HitBox(int x, int y, int a, int l){
       altura= a;
       largura= l;
       yp= y;
       xp= x;
      glBegin(GL_TRIANGLE_FAN);
          glVertex3f(-l+x, -a-c+y, 0);
          glVertex3f(l+x, -a-c+y, 0);
          glVertex3f(l+x, a+y, 0);
          glVertex3f(-l+x, a+y, 0);
      glEnd();
    }
 };

 struct hitbox player; //jogador
 struct hitbox e1;     //enemy 1
 struct hitbox e2; //enemy 2

int randomE1= 100;
int randomE2= 100;

int xVelocidade= 10;
int yVelocidade= 2;

float yPlayer=30;
int pulo=0;
int parametro= 401;

void fps(int a){
    glutPostRedisplay();
    glutTimerFunc(20, fps, 0); //50 FPS
}

int force= 8;

void pular(){
yPlayer= yPlayer + pulo*abs((yPlayer-parametro)/force);
if(yPlayer > 390){
    pulo= -1;
    parametro= 430;
}
if(yPlayer < 30 && parametro> 401){
    pulo= 0; yPlayer= 30;
}
}

void Montanha(){
    glColor3f(0.5, 0.5, 0.5);
glBegin(GL_TRIANGLE_FAN);
          glVertex3f(1280, -380, 0);
          glVertex3f(-1720, 220, 0);
          glVertex3f(-5280, -1300, 0);
          glVertex3f(5280, -1300, 0);
glEnd();
}

void testeColisao(struct hitbox alvo){
if(

(alvo.yp+ alvo.altura) > (player.yp- player.altura) && (alvo.yp+ alvo.altura) < (player.yp+ player.altura) && (alvo.xp - alvo.largura) < (player.xp + player.largura) && (alvo.xp - alvo.largura) > (player.xp - player.largura)

){
exit(0);
}



}

void desenhaCena(void){
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(1, 0, 0);
//desenha inimigos

        e1.HitBox(1280- e1.x,-300- e1.y ,100, 60);
         e1.x= e1.x + xVelocidade;
         e1.y= e1.y - yVelocidade ; //movimenta inimigo 1
         if(e1.x > (2560 + randomE1)){
             e1.x= 0; e1.y= 0; randomE1= 100 + (rand()%5000);}
          testeColisao(e1);

        e2.HitBox(1280- e2.x,-300- e2.y ,40, 60);
         e2.x= e2.x + xVelocidade;
         e2.y= e2.y - yVelocidade ;
        if(e2.x > (2560 + randomE1)){
             e2.x= 0; e2.y= 0; randomE2= 1000 + (rand()%1000);}
        testeColisao(e2);

glColor3f(0, 1, 0);
//desenha Lhama


pular(); //coordena o pulo com gravidade

        player.HitBox(-500, yPlayer, player.altura, 80);

Montanha();

    glFlush();
}

// Inicia algumas variáveis de estado
void inicializa(void){
    // cor para limpar a tela
    glClearColor(1, 1, 1, 0);      // branco
}

// Callback de redimensionamento
void redimensiona(int w, int h){
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-w, w, -h, h, -1, 1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

// Callback de evento de teclado
void teclado(unsigned char key, int x, int y)
{

   switch(key)
   {
      // Tecla ESC
      case 27:
         exit(0);
         break;
      case ' ':
      case 'w':
         if(pulo==0) {parametro=400;  pulo=1; force=8;}
        break;
      case 's':
        player.c = 60;
        player.altura= 40;
        break;
      default:
         break;
   }

}

void keyUp(unsigned char key, int x, int y){
  switch(key){
    case 's':
    player.altura = 100;
    player.c = 0;
    break;
    default:
    break;

  }

}


// Rotina principal
int main(int argc, char **argv)
{
    d.x = 1280;
    d.y = 720;
srand(time(0));
    // Acordando o GLUT
    glutInit(&argc, argv);
    glutTimerFunc(0, fps, 0);
    // Definindo a versão do OpenGL que vamos usar
    glutInitContextVersion(1, 1);
    glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);
    // Configuração inicial da janela do GLUT
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize(d.x, d.y);
    glutInitWindowPosition(0, 0);

    // Abre a janela
    glutCreateWindow("Lhamania");

glutSetKeyRepeat(GLUT_KEY_REPEAT_OFF);
    // Registra callbacks para alguns eventos

    glutDisplayFunc(desenhaCena);
    glutReshapeFunc(redimensiona);
    glutKeyboardFunc(teclado);
    glutKeyboardUpFunc(keyUp);
    inicializa();

    // Entra em loop e nunca sai
    glutMainLoop();
    return 0;
}
