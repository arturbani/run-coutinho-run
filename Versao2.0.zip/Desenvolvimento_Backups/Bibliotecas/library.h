#include <GL/glew.h>
#include <GL/freeglut.h>
#include <SOIL/SOIL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "structs.h"
#include "texto.h"
//#include "fimdejogo.h" //OBS:Precisa vir depois do texto.h necessariamente
#include "verificar.h"
#include "moedas.h"
#include "inimigos.h"
// #include "pulo.h"
