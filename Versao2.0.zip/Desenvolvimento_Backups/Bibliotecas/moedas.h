// #include "structs.h"
//Teste: Pois estou usando a struct quadrado, de outra library


//Inicializando como Moeda
void initAsMoeda(quadrado *a){
//Atribuir Classe: Quadrado como Subclasse: Moeda
  a->isMoeda = 1;
//Desatribuir das demais Classes: (Ou é moeda ou inimigo, não pode ser os 2)
  a->isInimigo = 0;

  a->visivel = 1; //A moeda vai estar de inicio visivel pro jogador

}


//Do tipo efeitos:
//O efeito, a consequencia, da moeda colidir
void colisaoMoeda(quadrado *a){
   // a->visivel = 0;
   a->x = -30;

//Highscore ++

  //Reset da colisão dentro da main
}




//Seção Animação

void inicializaMoeda(GLuint* texturaMoeda){
    // glClearColor(.9,.9,.9,0);
    // habilita mesclagem de cores, para termos suporte a texturas (semi-)transparentes
    glEnable(GL_BLEND );
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    *texturaMoeda = SOIL_load_OGL_texture(
        "Texturas/moeda.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y
	);

    if (texturaMoeda == 0) {
        printf("Erro do SOIL: '%s'\n", SOIL_last_result());
    }
}


// void moedax(float x0 ,float x1, float y0,float y1,GLuint texturaMoeda){
//         // Habilita o uso de texturas
//         glEnable(GL_TEXTURE_2D);
//
//         // Começa a usar a textura que criamos
//         glBindTexture(GL_TEXTURE_2D, texturaMoeda);
//         glBegin(GL_TRIANGLE_FAN);
//             // Associamos um canto da textura para cada vértice
//     glTexCoord2f(x0, y0); glVertex3f(-1, -1,  0);
//     glTexCoord2f(x1, y0); glVertex3f( 1, -1,  0);
//     glTexCoord2f(x1, y1); glVertex3f( 1,  1,  0);
//     glTexCoord2f(x0, y1); glVertex3f(-1,  1,  0);
//     glEnd();
//     glDisable(GL_TEXTURE_2D);
//
// }
