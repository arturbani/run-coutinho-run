#include <structs.h>
typedef struct Quadrado{
  //Atributos Base: Servem para qualquer Quadrado:
    int visivel;
    char nome [30];
    float x;
    float y;
    float tx;
    float ty;
    float r,g,b; //Cores
    struct Quadrado *proxquadrado;

  //Atributos Específicos: Para cada 'subclasse': (Obs:Cada subclasse possui sua propria library)
  //Moedas:
    int isMoeda; //Identidade (se é moeda ou não)

  //Inimigos:
    int isInimigo; //Identidade

  //PowerUp (Não Implementado):
    // int isPowerUpVoar //Exemplo:


}quadrado;

//Funções Base:

void nomeQuadrado(quadrado*a, char* asd){
  strcpy(a->nome,asd);
}



void posQuadrado(quadrado* a ,float xa,float ya ){
    a->x = xa;
    a->y = ya;
}

void tamQuadrado(quadrado* a,float xa, float ya){
    a->tx = xa;
    a->ty = ya;

}

void corQuadrado(quadrado *a,float r,float g,float b){
  a->r = r;
  a->g = g;
  a->b = b;

}

void linkQuadrado(quadrado *a, quadrado*b){
  a->proxquadrado = b;


}

void linkEnd(quadrado *a){
  a->proxquadrado = NULL;
}
