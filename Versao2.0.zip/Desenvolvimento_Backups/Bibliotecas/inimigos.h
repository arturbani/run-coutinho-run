// #include "structs.h"
//Teste: Pois estou usando a struct quadrado, de outra library


//Inicialização como Inimigo
void initAsInimigo(quadrado *a){
//Atribuição Classe: Quadrado Atribuir Subclasse: Inimigo
  a->isInimigo = 1;
//Desatribuir demais Classes:
  a->isMoeda = 0;

  a->visivel = 1; //Inimigo sempre visivel


}

//Efeitos:
//O efeito da colisão com Inimigo
void colisaoInimigo(quadrado *a){
  // GameOver();


}
