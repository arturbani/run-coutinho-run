
#include "Bibliotecas/library.h"

//Inicialização do programa
int init = 1;

//Indica Game Over(Tela de fim de jogo)
int theEnd = 0;

//Timer (FPS)
int timer =24;

int score=0; //Uma funçao que aumenta com o tempo

//Movimento:
int MovimentarOn=0; //Define se o movimento esta ativo (Tecla P) (TESTE)
int ColisaoOn=0;


//Pulo:
int PularOn = 0;
float oldpulo;
float pulo = 5; //o quanto eu vou pra cima no y (variação do y)
float incPulo = 0.5; //incremento no y (variação da variação)



//Spawn:
//OBS: Atentar à função mudaCorrida que pega valores determinados
int MAX_RANDOM_SPAWN = 50; //Random Spawn (Determina o limite dos numeros randômicos)
float MIN_DIST_SPAWN = 100; //Distância do Spawn (Determina a distância minima para o Spawn)

float velocidade = 3;


//Nivel, Posição Y do chão
int INICIO_DO_MUNDO = 0;
int FIM_DO_MUNDO = 100;
int groundlevel =30;
int TXDEFAULT = 10;
int TYDEFAULT = 10;

float aspect; //Ainda não mexi, para arrumar o AspectRatio(TESTE).


//Declarar variaveis to tipo Struct('Classe') Quadrado:
//Declaração Jogador (POR ENQUANTO EH DA MESMA SUBCLASSE QUE UM INIMIGO)
quadrado q1; //Depois pode mudar para j1.

//Declaração (Subclasse) Inimigos
quadrado q2,q3,q4;

//Declaração (Subclasse) Moedas:
quadrado moeda1; //Possivelmente como um vetor (caso tenha muiiitas, multiplas moedas). //Nao sei se precisa, pq ja tem a lista encadeada linkando a porra toda.






//SEÇÃO RESPAWN

//Essa função retorna a posição X do objeto mais distante( Mais a Direita do jogador), util para as funções Respawn
//Retorna somente a posição do inimigo
float objMaisDistante(){
  float n =q2.x;
  quadrado *i = &(q2);
  do{
    if(i->isInimigo)
    if( i->x > n)
    n = i->x;
    // if( (i->proxquadrado)->isInimigo )
    i = i->proxquadrado;
  }
  while ( (i) != NULL);


  return n;
}



// //Respawn do Objeto
void eventoRespawn(quadrado *a){

  //Primeiramente: Descobre a posição do objeto mais distante;
  float posMaior = objMaisDistante();

  //Atribui um valor da variação para ser somado à posição;
  float valorVariacao = rand()%MAX_RANDOM_SPAWN + MIN_DIST_SPAWN;


   //Determina a nova Posição do Quadrado;
      posQuadrado(a, posMaior+valorVariacao ,groundlevel+0);



  printf("Respawnou:%s\n",a->nome); //debug
}



// Muda o tipo de corrida(mexendo nos valores MAX_RANDOM_SPAWN e MIN_DIST_SPAWN)- X: Valor recebido pelo glutTimerFunc( Tempo para chamar a função)
void mudaCorrida(int X){
  printf("Mudando tipo de corrida:\n");
  if(MIN_DIST_SPAWN == 100){
    X*=2; //Teste dobrar o tempo para chamar a função
    MIN_DIST_SPAWN = 50;
    MAX_RANDOM_SPAWN = 300;
  }
  else{
    X/=2; //Teste - dividir o tempo para chamar a função
    MIN_DIST_SPAWN = 100;
    MAX_RANDOM_SPAWN = 60;
  }
  // glutTimerFunc(X,mudaCorrida,X);
}

quadrado *pointer;

void respawnMoeda(){
 eventoRespawn(pointer); 
}

// //Reposicionar o objeto caso ele tenha saido de Cena (para os quadrados "inimigos"),
// //Para um mundo começando no eixo X.
void verificaPosicao(quadrado *a){
//Quando o quadrado percorrer até o final do mundo, (tendo percorrido todo seu tamanho);
  if( a->x < -(a->tx)+INICIO_DO_MUNDO ){
    if(a->isInimigo)
    eventoRespawn(a);

  pointer = a;
    if(a->isMoeda)
    glutTimerFunc(10000,respawnMoeda,10000);

    }
    a->visivel = 1;

}

void verificaTipo(quadrado *a){
  if(a->isMoeda){
    if(ColisaoOn){
          colisaoMoeda(a,&score);
      ColisaoOn=0; //Nao sei se fica aqui ou dentro da função. Para resetar o valor de colisao pq tem de sumir a moeda
    }
    // animacaoMoeda(a);
  }
  if (a->isInimigo){
    if(ColisaoOn){
        GameOver(&MovimentarOn,&theEnd);
        ColisaoOn=0;
    }
  }



}



//             (quadrado, velocidade)
void movimenta(){
  //Usar lista estatica
  q2.x-=velocidade;
  q3.x-=velocidade;
  q4.x-=velocidade;
  moeda1.x-=velocidade;

}


void puloBackup(){
  oldpulo = pulo;
}


void resetPulo(){
  pulo = oldpulo;
  PularOn = 0;
}


void pular(){
    q1.y+=pulo;
    pulo-=incPulo;

//Verifica se o jogador chegou na altura do chão para parar o pulo
    if(q1.y<=groundlevel)
        resetPulo();

}




void atualiza(int timer){
//MovimentarOn para controlar se o movimento está ativo ou não
  if (MovimentarOn==1){
      movimenta();

//PularOn para controlar se o pulo está ativo ou não
  if(PularOn==1)
    pular();
  }


  glutPostRedisplay();
  glutTimerFunc(timer,atualiza,timer);

}

void desenhaQuadrado(quadrado* a){
    glColor3f(a->r,a->g,a->b);

    //Para nao verificar do jogador com ele mesmo(MODIFICAR)
    if(a!=&q1)  //MODIFICAR DEPOIS
    verificaColisao(a,&q1,&ColisaoOn); //MODIFICAR DEPOIS
    verificaPosicao(a);
    verificaTipo(a);

    //Para somente desenhar se visibilidade 'on'(== 1)
    if(a->visivel){  //Teste
    glBegin(GL_TRIANGLE_FAN);

      glVertex2d(a->x , a->y);
      glVertex2d(a->x + a->tx, a->y);
      glVertex2d(a->x + a->tx, a->y + a->ty);
      glVertex2d(a->x , a->y + a->ty);

    glEnd();
  }

}



void desenhaCena(){
  glClear(GL_COLOR_BUFFER_BIT);

  glEnable(GL_BLEND); // teste pra opacidade
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  //Usar a lista encadeada depois
  desenhaQuadrado(&q1);
  desenhaQuadrado(&q2);
     desenhaQuadrado(&q3);
     desenhaQuadrado(&q4);
     desenhaQuadrado(&moeda1);

//Verifica o se o jogador perdeu ou não, indo pro tela do fim (GAME-OVER) (MODIFICAR)
 if (theEnd==1)
  /*Teste: Ao verificar que o jogo chegou ao fim, chama a função GameOver
  que eh responsavel por parar com o movimento(p/tirar essa responsabilidade da funcao colisao)
  e GameOver agora, eh responsavel pelo final do jogo(chamar funcao telaFim, por exemplo).*/
     GameOver(&MovimentarOn,&theEnd);

  glutSwapBuffers();

}


void redimensiona(int width, int height){
  aspect = width/height;
  glViewport(0,0,width,height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(INICIO_DO_MUNDO,FIM_DO_MUNDO*aspect,0,100*aspect,-1,1);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();


}

//INICIALIZAÇÃO DOS OBJETOS
void initQuadrado(){
//Para inicializar o quadrado somente uma vez. Podendo atualizar ele sem preocupações
  if (init==1){
    puloBackup(); //Guarda o valor inicial de pulo
  init++;

  initAsInimigo(&q1); //TEMPORARIO
  tamQuadrado(&q1,10,15);
  posQuadrado(&q1,5,groundlevel);
  corQuadrado(&q1,.8,.1,.1);

  nomeQuadrado(&q2,"q2");  //NÃO ESTA EM USO(SOMENTE PARA TESTES) (IDEIA NOMES LEGAIS ALEATORIOS PARA QUANDO MORRER APARECER --- ROGUE LEGACY)
  initAsInimigo(&q2);
  tamQuadrado(&q2,TXDEFAULT,TYDEFAULT);
  posQuadrado(&q2,90,groundlevel);
  corQuadrado(&q2,.1,.3,.9);
  linkQuadrado(&q2,&q3);

  nomeQuadrado(&q3,"q3");
  initAsInimigo(&q3);
  tamQuadrado(&q3,TXDEFAULT,TYDEFAULT);
  posQuadrado(&q3,180,groundlevel);
  corQuadrado(&q3,.8,.5,.1);
  // corQuadrado(&q3,.1,.3,.9);
  // linkEnd(&q3);
  linkQuadrado(&q3,&q4);

  nomeQuadrado(&q4,"q4");
  initAsInimigo(&q4);
  tamQuadrado(&q4,TXDEFAULT,TYDEFAULT);
  posQuadrado(&q4,270,groundlevel);
  corQuadrado(&q4,.8,.3,.9);
  // corQuadrado(&q4,.1,.3,.9);
  // linkEnd(&q4);
  linkQuadrado(&q4,&moeda1);

  nomeQuadrado(&moeda1,"moeda1");
  initAsMoeda(&moeda1);
  tamQuadrado(&moeda1,TXDEFAULT+5,TYDEFAULT+5);
  posQuadrado(&moeda1,140,groundlevel);
  corQuadrado(&moeda1,.5,.6,.6);
  // linkEnd(&moeda1);
  linkQuadrado(&moeda1,NULL);

  }
}


void resetAll(){    //Da para colocar um variavel para avisar se volta em movimento ou nao
  theEnd = 0;
  resetPulo();
  init = 1;
  MovimentarOn = 0;
  initQuadrado();
  glutPostRedisplay();
}



//KEYBOARD:
void keyboard(unsigned char key, int x, int y){

  switch (key){
    case 27:
      exit(0);
      break;

  //Pause (Desenvolvimento);
    case 'p':
    case 'P':
    case 'c':
    case 'C':
        verificarLiberarMovimento(&theEnd, &MovimentarOn );
    break;

    case 13: //Enter
      // Tela de Fim de Jogo
        if(theEnd==1){
            resetAll();
        }
    break;

    //Reset em qualquer momento
    case 'r':
    case 'R':
      resetAll();
    break;

    case 32: //Barra de Espaço
    if(MovimentarOn){ //IGNORAR -> //MANEIRA CORRETA - VOLTAR NA VERSÃO FINAL
     // if(ColisaoOn){ //IGNORAR
      if(PularOn==0)
        PularOn=1;
    }
      break;

    default:
      break;


  }

}

void inicializa(){
  glClearColor(.3,.3,.3,0);
  initQuadrado();
}

void aumentaScore(int tempo){
  if(MovimentarOn)
    score+=100;
  if(tempo>=2000);
    tempo-=500;
  printf("Score:%i\n",score);
  if(theEnd==0)
  glutTimerFunc(tempo/velocidade,aumentaScore,tempo/velocidade);
}



int main(int argc, char**argv){
  //Inicializar o glut
  glutInit(&argc,argv);

  //Configurações de inicialização do glut
  glutInitContextVersion(1,1);
  glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

  //Configurações da Janela
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
  glutInitWindowSize(400,400);
  glutInitWindowPosition(100,100);

  //Abrir(criar) Janela
  glutCreateWindow("Teste");
  inicializa();

  srand(time(NULL));

  //Callbacks
  // initQuadrado(); //Foi passado pra inicializa
  glutDisplayFunc(desenhaCena);
  glutReshapeFunc(redimensiona);
  glutKeyboardFunc(keyboard);
  glutTimerFunc(timer,atualiza,timer);
  // glutTimerFunc(6000,mudaCorrida,6000); //Teste...
    glutTimerFunc(6000,aumentaScore,6000);


  glutMainLoop();
  return 0;

}
