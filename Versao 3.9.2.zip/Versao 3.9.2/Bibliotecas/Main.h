int main(int argc, char**argv);
void inicializaOGlut(int argc,char**argv);
