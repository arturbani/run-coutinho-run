

// void Animacao_Textura_Jogador1(struct Quadrado *Objeto);



void reposicionaViewTextura(float XInicial,float XFinal,
  float YInicial,float YFinal,
  textura_animacao *textura);


 void Animacao_Textura_Jogador1(textura_animacao *textura, int PularOn, int RolamentoOn, int *RolamentoContadorFrames);


 void Animacao_Textura_MoedaRing(textura_animacao *textura);

 void Animacao_Textura_Lobo(textura_animacao *textura);


 void Animacao_Textura_Goomba(textura_animacao *textura);

 void Animacao_Textura_MutantCrab(textura_animacao *textura);

 void Animacao_Textura_OlhoVoador(textura_animacao *textura);

 void Animacao_Textura_MoedaGoldCoin(textura_animacao *textura);

 void Animacao_Textura_CaveiraFogo(textura_animacao *textura);

 void Animacao_Textura_CaveiraSemFogo(textura_animacao *textura);

 void Animacao_Textura_LostVikingsSoldier(textura_animacao *textura);

 void Animacao_Textura_AnimaniacsPolicialGordo(textura_animacao *textura);

 void Animacao_Textura_DonaldArabian(textura_animacao *textura);

 void Animacao_Textura_DemonioFudendoVoador(textura_animacao *textura);

 void Animacao_Textura_RolyPoly(textura_animacao *textura);
