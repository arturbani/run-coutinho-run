
void texto(void* font, char* s, float x, float y);

char *my_itoa(int num, char *str);

void mostraScore(int score);

void telaFim();

//Depois Mudar de Lugar(Temporário);
void GameOver(int* MovimentarOn,int *theEnd);
