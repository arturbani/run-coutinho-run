
#include "Bibliotecas/library.h"

//Inicialização do programa
int init = 1;

// int EstaNoMenu = 1;
// int EstaNoJogo = 0;

//Indica Game Over(Tela de fim de jogo)
int theEnd = 0;

int RandomEnemiesOn = 1;

//Timer (FPS)
int fpstimer =24;

int timerAnimacaoJogador = 100;

int Score=0; //Uma funçao que aumenta com o tempo

// Menu inicial:
int MenuOn=1;
int contador_selecao=1;

//Pause:
int sair=0;
char acao='M';
int PauseOn=0;
int ConfirmaOn=0;
int contador_seta=1;
int contador_seletor=1;

//Movimento:
int MovimentarOn=0; //Define se o movimento esta ativo (Tecla P) (TESTE)
int ColisaoOn=0;

//Rolamento:
int RolamentoOn=0;
int RolamentoContadorFrames = 0;
int RolamentoMaxFrames = 10;

//Pulo:
int PularOn = 0;
float oldpulo;
float pulo = 5; //o quanto eu vou pra cima no y (variação do y)
float incPulo = 0.5; //incremento no y (variação da variação)



//Spawn:
//OBS: Atentar à função mudaCorrida que pega valores determinados
int MAX_RANDOM_SPAWN = 100; //Random Spawn (Determina o limite dos numeros randômicos)
int MIN_DIST_SPAWN = 130; //Distância do Spawn (Determina a distância minima para o Spawn]
int mudaCorridaTimer = 10000; //(TESTE)
int aumentaScoreTimer = 4000;

float velocidade = 3.0;


//Nivel, Posição Y do chão
int INICIO_DO_MUNDO = 0;
int FIM_DO_MUNDO = 100;
int ALTURA_DO_MUNDO = 90;
int LARGURA_DO_MUNDO = 160;
int CHAO_DO_MUNDO = 0;
int ALTURA_DA_GRAMA = -10;

int groundlevel = 8;
int MOEDA_ALTURA = 45;
quadrado *Ponteiro_Moeda; //Aponta para a moeda para a hora do seu respawn.


int VOADOR_INCREMENTO_ALTURA_MINIMA = 10;
int VOADOR_INCREMENTO_ALTURA_MAXIMA = 4;

int TXMOEDA = 10;
int TYMOEDA = 10;

int TXDEFAULT = 13;
int TYDEFAULT = 13;
int TXPLAYER = 15;
int TYPLAYER = 15;
int TXPLAYER_ROLL = 13;
int TYPLAYER_ROLL = 10;

float aspect; //Ainda não mexi, para arrumar o AspectRatio(TESTE).

float velocidade_g = 2.5;
float velocidade_f = -.1;


//Declarar variaveis to tipo Struct('Classe') Quadrado:

// Fundo do jogo
quadrado fundo1, grama1;
quadrado fundo2, grama2;

// Menu inicial
quadrado logo, seta, texto_iniciar, texto_controles;
quadrado texto_sair, texto_creditos;

//Declaração Jogador
quadrado q1; //Player

//Declaração Inimigos
quadrado q2,q3,q4;
quadrado voador1,voador2;


//Declaração Colecionaveis(Moedas e PowerUps):
quadrado moeda1; //Possivelmente como um vetor (caso tenha muiiitas, multiplas moedas). //Nao sei se precisa, pq ja tem a lista encadeada linkando a porra toda.
quadrado pw1;


//Texturas:
GLuint Textura_Fundo, Textura_Fundo2, Textura_Grama,Textura_MoedaRing,
Textura_MoedaGoldCoin, Textura_CaveiraFogo,Textura_CaveiraSemFogo,
Textura_Fogueira1,Textura_Lobo1,Textura_Lobo2, Textura_GoombaRunning,
Textura_MutantCrab, Textura_OlhoVoador, Textura_DemonioFudendoVoador;
GLuint Textura_RolyPolyRoxo,Textura_RolyPolyVerde,Textura_RolyPolyMarrom,
Textura_RolyPolyPreto;


GLuint Textura_LostVikingsSoldier, Textura_AnimaniacsPolicialGordo;
GLuint Textura_DonaldArabian;

GLuint Textura_Jogador1, Textura_Jogador1_Roll, Textura_Jogador1_Pulo, Textura_Jogador1_Morte;

// Menu inicial
GLuint Textura_Logo, Textura_Jogar, Textura_Controles;
GLuint Textura_Seletor;

// Menu de Pause
GLuint Textura_Popup;
GLuint Textura_Texto_Pause, Textura_Voltar_Jogo, Textura_Texto_Reiniciar, Textura_Texto_Menu, Textura_Texto_Sair;

// Confirmacao
GLuint Textura_Seletor_Botao, Textura_BotaoS, Textura_BotaoN;
GLuint Textura_Texto_Confirmacao;



void inicializaTextura(){
  glClearColor(.9,.9,.9,0);

//Menu
  Textura_Logo = SOIL_load_OGL_texture("texturas/Menu/logo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Jogar = SOIL_load_OGL_texture("texturas/Menu/jogar.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Controles = SOIL_load_OGL_texture("texturas/Menu/controles.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Seletor = SOIL_load_OGL_texture("texturas/seta.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  // Textura_Seta = SOIL_load_OGL_texture("texturas/Menu/seta.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
//Jogo
  Textura_Fundo  = SOIL_load_OGL_texture("texturas/fundo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Fundo2  = SOIL_load_OGL_texture("texturas/fundo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Grama  = SOIL_load_OGL_texture("texturas/grama.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Jogador1 = SOIL_load_OGL_texture("texturas/coutinho.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Jogador1_Roll  = SOIL_load_OGL_texture("texturas/rolamento.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_MoedaRing = SOIL_load_OGL_texture("texturas/SonicRingCoin.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_MoedaGoldCoin = SOIL_load_OGL_texture("texturas/GoldCoin.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Fogueira1 = SOIL_load_OGL_texture("texturas/Fire_Pit.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Lobo1 = SOIL_load_OGL_texture("texturas/wolf-runing-cycle-skin.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Lobo2 = SOIL_load_OGL_texture("texturas/wolf-runing-cycle.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_GoombaRunning = SOIL_load_OGL_texture("texturas/GoombaRunning.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_MutantCrab = SOIL_load_OGL_texture("texturas/mutant_crab.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_LostVikingsSoldier = SOIL_load_OGL_texture("texturas/LostVikingsSoldier.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_AnimaniacsPolicialGordo = SOIL_load_OGL_texture("texturas/AnimaniacsPolicialGordo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_DonaldArabian = SOIL_load_OGL_texture("texturas/DonaldArabian.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_OlhoVoador = SOIL_load_OGL_texture("texturas/OlhoVoador.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_CaveiraFogo = SOIL_load_OGL_texture("texturas/fire-skull.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_CaveiraSemFogo = SOIL_load_OGL_texture("texturas/no-fire-skull.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_DemonioFudendoVoador = SOIL_load_OGL_texture("texturas/demon-idle.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_RolyPolyRoxo = SOIL_load_OGL_texture("texturas/ChronoTrigger/purpleRolyPoly_CT.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_RolyPolyVerde = SOIL_load_OGL_texture("texturas/ChronoTrigger/greenRolyPoly_CT.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_RolyPolyMarrom = SOIL_load_OGL_texture("texturas/ChronoTrigger/brownRolyPoly_CT.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_RolyPolyPreto = SOIL_load_OGL_texture("texturas/ChronoTrigger/blackRolyPoly_CT.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);

  // menu de pause
  Textura_Popup = SOIL_load_OGL_texture("texturas/popup.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Texto_Pause = SOIL_load_OGL_texture("texturas/pause_texto.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Voltar_Jogo = SOIL_load_OGL_texture("texturas/voltar_jogo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Texto_Reiniciar = SOIL_load_OGL_texture("texturas/reiniciar.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Texto_Menu = SOIL_load_OGL_texture("texturas/go_menu.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Texto_Sair = SOIL_load_OGL_texture("texturas/sair_do_jogo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);

  // confirmacao
  Textura_Popup = SOIL_load_OGL_texture("texturas/popup.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Texto_Confirmacao = SOIL_load_OGL_texture("texturas/confirmacao.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_Seletor_Botao = SOIL_load_OGL_texture("texturas/seletor_botao.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_BotaoS = SOIL_load_OGL_texture("texturas/botao_sim.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  Textura_BotaoN = SOIL_load_OGL_texture("texturas/botao_nao.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);


  if(Textura_MutantCrab== 0){
      printf("[Texture loader] \"%s\" failed to load!\n", SOIL_last_result());
  }

}

int VariacoesDeInimigos = 16;


//SEÇÃO RESPAWN

void randomizarInimigos(quadrado *Inimigo){
  int NumeroAleatorio;
  if(Inimigo->y > groundlevel)
    posQuadrado(Inimigo,Inimigo->x,groundlevel);
    // NumeroAleatorio = rand()%4+50;
  // else
  NumeroAleatorio = rand()%VariacoesDeInimigos+1;
  // NumeroAleatorio = 8; //Para teste direto de textura
  switch (NumeroAleatorio){

    //Lobo1
    case 1:
      tamQuadrado(Inimigo,16,10);
      texturaQuadrado(Inimigo,Textura_Lobo1);
    break;
    //Lobo2:
    case 2:
      tamQuadrado(Inimigo,16,10);
      texturaQuadrado(Inimigo,Textura_Lobo2);
    break;
    //Goomba
    case 3:
      tamQuadrado(Inimigo,13,13);
      texturaQuadrado(Inimigo,Textura_GoombaRunning);
    break;
    //GoombaBigger
    case 4:
      tamQuadrado(Inimigo,15,15);
      texturaQuadrado(Inimigo,Textura_GoombaRunning);
    break;
    //MutantCrab(Caranguejo Fudidao)
    case 5:
      tamQuadrado(Inimigo,13,13);
      texturaQuadrado(Inimigo,Textura_MutantCrab);
    break;
    //LostVikingsSoldier
    case 6:
      tamQuadrado(Inimigo,14,15);
      texturaQuadrado(Inimigo,Textura_LostVikingsSoldier);
    break;
    //AnimaniacsPolicialGordo
    case 7:
      tamQuadrado(Inimigo,20,18);
      texturaQuadrado(Inimigo,Textura_AnimaniacsPolicialGordo);
    break;
    //DonaldArabian
    case 8:
      tamQuadrado(Inimigo,17,17);
      texturaQuadrado(Inimigo,Textura_DonaldArabian);
    break;

    /*
    A partir daqui começam textura de voadores. É preciso setar sua posição como acima do nivel do chão,
    para que, na função eventoRespawn, ocorra o seu respawn como o de um voador.
    */
    //OlhoVoador
    case 9:
      tamQuadrado(Inimigo,15,13);
      texturaQuadrado(Inimigo,Textura_OlhoVoador);
      posQuadrado(Inimigo,Inimigo->x,groundlevel+1);
    break;
    //Caveira de Fogo
    case 10:
      tamQuadrado(Inimigo,15,15);
      texturaQuadrado(Inimigo,Textura_CaveiraFogo);
      posQuadrado(Inimigo,Inimigo->x,groundlevel+1);
    break;
    //Caveira Sem Fogo
    case 11:
      tamQuadrado(Inimigo,13,13);
      texturaQuadrado(Inimigo,Textura_CaveiraSemFogo);
      posQuadrado(Inimigo,Inimigo->x,groundlevel+1);
    break;
    case 12:
      tamQuadrado(Inimigo,42,33);
      texturaQuadrado(Inimigo,Textura_DemonioFudendoVoador);
      posQuadrado(Inimigo,Inimigo->x,groundlevel+1);
    break;

    int cor = rand()%4+1;

  //RolyPolys:ChronoTrigger)
  //Roxo
  case 13:
    texturaQuadrado(Inimigo,Textura_RolyPolyRoxo);
    tamQuadrado(Inimigo,13,13);
  break;
  //Preto
  case 14:
    texturaQuadrado(Inimigo,Textura_RolyPolyPreto);
    tamQuadrado(Inimigo,13,13);
  break;
  //Marrom
  case 15:
    texturaQuadrado(Inimigo,Textura_RolyPolyMarrom);
    tamQuadrado(Inimigo,13,13);
  break;
  //Verde
  case 16:
    texturaQuadrado(Inimigo,Textura_RolyPolyVerde);
    tamQuadrado(Inimigo,13,13);
  break;

}

}









// //Respawn do Objeto
void eventoRespawn(quadrado *a){
  if(a->isInimigo)
  if(RandomEnemiesOn)
    randomizarInimigos(a);

  //Primeiramente: Descobre a posição do objeto mais distante;
  float posMaior = posMaisDistante(&q2);

  //Atribui um valor da variação para ser somado à posição;
  float valorVariacao = rand()%MAX_RANDOM_SPAWN + MIN_DIST_SPAWN;

   if(a->isMoeda)
    posQuadrado(a,posMaior+valorVariacao,MOEDA_ALTURA);

   //Para o caso de inimigos voadores, muda ligeiramente sua altura.
   else if(a->y > groundlevel){
     int valorVariacaoInimigoVoador = (rand()%VOADOR_INCREMENTO_ALTURA_MAXIMA)+VOADOR_INCREMENTO_ALTURA_MINIMA+groundlevel;
     posQuadrado(a,posMaior+valorVariacao,valorVariacaoInimigoVoador);
   }

   //Para os demais inimigos
   else
      posQuadrado(a, posMaior+valorVariacao,a->y);


  // printf("Respawnou:%s\n",a->nome); //debug
}




void respawnMoeda(){
  if(Ponteiro_Moeda->x  < INICIO_DO_MUNDO){
    eventoRespawn(Ponteiro_Moeda);
    // printf("Respawn\n");
  }

}

// //Reposicionar o objeto caso ele tenha saido de Cena (para os quadrados "inimigos"),
// //Para um mundo começando no eixo X.
void verificaPosicao(quadrado *a){
 /*Quando o quadrado percorrer até o final do mundo, (tendo percorrido todo seu tamanho);

 */
  if( a->x < -(a->tx)+INICIO_DO_MUNDO ){
    if(a->isInimigo)
    eventoRespawn(a);

     if(a->isMoeda){
      Ponteiro_Moeda = a;
      glutTimerFunc(4000,respawnMoeda,0); //Para a moeda respawnar pelo tempo.
    }

     if(a->isFundo){
       posQuadrado(a, a->tx-velocidade_g ,a->y);
       glutPostRedisplay();
     }


  }


  a->visivel = 1; //Retorna pra sua visibilidade, caso tenha sido alterada
}

void verificaTipo(quadrado *a){
 /*Após verificar a colisão, verifica o tipo do quadrado, ou seja:
  se é Moeda(isMoeda), Inimigo(isInimigo), e com isso reage da maneira apropriada
  (ex:Inimigo, ocorre o GameOver, ou seja, o personagem morreu.
      No caso da Moeda, chama a função colisãoMoeda(), responsável por aumentar
      o Score do jogo )
 */

  if(ColisaoOn){
    if(a->isMoeda){
      colisaoMoeda(a,&Score);
    }

    if (a->isInimigo){
      GameOver(&MovimentarOn,&theEnd);
    }

    // if(a->isPowerUp){
    //     //MexerDepois
    //
    // }

    ColisaoOn=0; //Resetar a Colisao
  }

}


//Movimenta os Inimigos
void movimentaInimigos(){
  //Tbm pode ser implementado lista encadeada, mas não houve necessidade.
  q2.x-=velocidade;
  q3.x-=velocidade;
  q4.x-=velocidade;
  moeda1.x-=velocidade/2; //VELOCIDADE ITENS PEGAVEIS (MUDAR DEPOIS)
  voador1.x-=velocidade;
  pw1.x-=velocidade/1.5;

}



void rolar(quadrado * a){
  if(RolamentoOn==1){
    texturaQuadrado(a,Textura_Jogador1_Roll);
    reposicionaViewTextura(0 , 1 , .75, 1, &q1.animacao);
    a->ty = TYPLAYER_ROLL;
    a->tx = TXPLAYER_ROLL;
    RolamentoOn = 2;
  }

  // MovimentarOn = 0;
  if(RolamentoContadorFrames >= RolamentoMaxFrames)
    resetRolamento(&q1,Textura_Jogador1,TXPLAYER,TYPLAYER,&RolamentoOn,&RolamentoContadorFrames);

}

//Movimenta o cenário
void movimentaCenario(){
  if(MovimentarOn){
    fundo1.x+=velocidade_f;
    fundo2.x+=velocidade_f;
      grama1.x-=velocidade_g;
      grama2.x-=velocidade_g;

  }

  if (MenuOn){
    fundo1.x+=velocidade_f;
    fundo2.x+=velocidade_f;
    grama1.x-=velocidade_g-1.9;
    grama2.x-=velocidade_g-1.9;

  }

  

}




void atualiza(int fpstimer){

  //O jogo precisa estar ocorrendo.
  if(theEnd==0){

      //MovimentarOn para controlar se o movimento está ativo ou não
      if (MovimentarOn==1){
        movimentaInimigos();

        //RolamentoON para controlar se o rolamento está ativo ou não
        if (RolamentoOn>0)
          rolar(&q1);

         //PularOn para controlar se o pulo está ativo ou não
        if(PularOn>0)
          pular(&q1,&pulo,&oldpulo,&incPulo,&groundlevel,&PularOn);
      }

      reposiciona_seta(&seta);

      movimentaCenario();
      glutPostRedisplay();

  }
  glutTimerFunc(fpstimer,atualiza,fpstimer);
}



//Verica se vai mudar ou nao de textura
void verificaTextura(int timer){
  //Desembolar uma lista encadeada nessa porra

  quadrado *i; //Iteração
    i = &(q1);

    if(MovimentarOn)
  do{

    //Se textura for igual à textura do jogador
    if(i->textura == Textura_Jogador1)
      Animacao_Textura_Jogador1(&(i->animacao),PularOn, RolamentoOn, &RolamentoContadorFrames);
    else if(i->textura == Textura_Jogador1_Roll)
      Animacao_Textura_Jogador1(&(i->animacao),PularOn, RolamentoOn, &RolamentoContadorFrames);

    //Se textura for igual a da moeda
    if(i->textura == Textura_MoedaRing )
      Animacao_Textura_MoedaRing(& (i->animacao) );

    //Se textura for igual ao do lobo
    if(i->textura == Textura_Lobo1 ||
        i->textura == Textura_Lobo2 )
      Animacao_Textura_Lobo(&(i->animacao));

    if(i->textura == Textura_GoombaRunning)
      Animacao_Textura_Goomba(&(i->animacao));

    if(i->textura == Textura_MutantCrab)
      Animacao_Textura_MutantCrab(&(i->animacao));

    if(i->textura == Textura_OlhoVoador)
      Animacao_Textura_OlhoVoador(&(i->animacao));

    if(i->textura == Textura_MoedaGoldCoin)
      Animacao_Textura_MoedaGoldCoin(&(i->animacao));

    if(i->textura == Textura_CaveiraFogo)
      Animacao_Textura_CaveiraFogo(&(i->animacao));

    if(i->textura == Textura_CaveiraSemFogo)
      Animacao_Textura_CaveiraSemFogo(&(i->animacao));

    if(i->textura == Textura_LostVikingsSoldier)
      Animacao_Textura_LostVikingsSoldier(&(i->animacao));

    if(i->textura == Textura_AnimaniacsPolicialGordo)
      Animacao_Textura_AnimaniacsPolicialGordo(&(i->animacao));

    if(i->textura == Textura_DonaldArabian)
      Animacao_Textura_DonaldArabian(&(i->animacao));

    if(i->textura == Textura_DemonioFudendoVoador)
      Animacao_Textura_DemonioFudendoVoador(&(i->animacao));
    if(i->textura == Textura_RolyPolyRoxo ||
       i->textura == Textura_RolyPolyVerde ||
       i->textura == Textura_RolyPolyPreto ||
       i->textura == Textura_RolyPolyMarrom)
       Animacao_Textura_RolyPoly(&(i->animacao));




    i = i->proxquadrado;
  }
  while( (i)!= NULL);


  glutTimerFunc(timer,verificaTextura,timer);
}




void desenhaQuadrado(quadrado* a){
  // if(a->isInimigo==1)
    // glColor4f(0,0,0,.0);
      // glClear(GL_COLOR_BUFFER_BIT);


    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);


    //Para nao verificar do jogador com ele mesmo(MODIFICAR)
    if(a->colidivel)
    verificaColisao(a,&q1,&ColisaoOn); //MODIFICAR DEPOIS

    verificaPosicao(a);
    verificaTipo(a);



    //Para somente desenhar se visibilidade 'on'(== 1)
    if(a->visivel){  //Teste
      glBindTexture(GL_TEXTURE_2D, a->textura);
      glBegin(GL_TRIANGLE_FAN);

      glTexCoord2f(a->animacao.X_Inicio_Textura, a->animacao.Y_Inicio_Textura);  glVertex3f(a->x, a->y,  0)  ;
      glTexCoord2f(a->animacao.X_Final_Textura,   a->animacao.Y_Inicio_Textura);  glVertex3f(a->x + a->tx, a->y,  0);
      glTexCoord2f(a->animacao.X_Final_Textura,   a->animacao.Y_Final_Textura);    glVertex3f(a->x + a->tx, a->y + a->ty,  0);
      glTexCoord2f(a->animacao.X_Inicio_Textura, a->animacao.Y_Final_Textura);    glVertex3f(a->x, a->y + a->ty,  0);

      glEnd();
  }



}

void desenhaFundo(){
 /*Desenha todos os quadrados com a propriedade IsFundo.
  A implementação se fez por meio de uma lista encadeada que passa desde o primeiro
  quadrado do fundo até o ultimo.
 */
  quadrado *Fundo_Pointer; //Ponteiro Iteração(Aposta para os quadrados)
    Fundo_Pointer = &(fundo1);
  do{
    desenhaQuadrado(Fundo_Pointer);
    Fundo_Pointer = Fundo_Pointer->proxquadrado;
  }
  while ( Fundo_Pointer->isFundo );

}

void reposiciona_seta(quadrado * seta){
    if (contador_selecao == 1){
        seta->x = (160-30)/2;
        seta->y = 30;
        }

    if (contador_selecao == 2){
        seta->x = (160-42)/2;
        seta->y = 25;
    }

    if (contador_selecao == 3){
        seta->x = (160-51)/2;
        seta->y = 20;
    }

}

void desenhaCena(){

  glClear(GL_COLOR_BUFFER_BIT);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_TEXTURE_2D);
  //Em Implementação
  desenhaFundo();

  // if(EstaNoJogo == 1){
  desenhaQuadrado(&q1);
     desenhaQuadrado(&q2);
     desenhaQuadrado(&q3);
     desenhaQuadrado(&q4);
     desenhaQuadrado(&moeda1);
     // desenhaQuadrado(&pw1);
     desenhaQuadrado(&voador1);

   if (PauseOn==1){
    pausa(contador_seta, Textura_Popup, Textura_Texto_Pause, Textura_Voltar_Jogo, Textura_Texto_Reiniciar,
          Textura_Texto_Menu, Textura_Texto_Sair, Textura_Seletor);
      if (ConfirmaOn==1){
        confirmacao(contador_seletor, acao, &sair, Textura_Popup,  Textura_Seletor_Botao, Textura_Texto_Confirmacao, Textura_BotaoS, Textura_BotaoN);
      }
  }

  glDisable(GL_TEXTURE_2D);
  mostraScore(Score);
  glDisable(GL_BLEND);
  // }
  glutSwapBuffers();

}


void desenhaMenu(){
  glClear(GL_COLOR_BUFFER_BIT);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_TEXTURE_2D);
  
  //Em Implementação
  desenhaFundo();

  desenhaQuadrado(&logo);
  desenhaQuadrado(&seta);
  desenhaQuadrado(&texto_iniciar);
  desenhaQuadrado(&texto_controles);
  // desenhaQuadrado(&texto_creditos);
  desenhaQuadrado(&texto_sair);

  if (ConfirmaOn==1){
        confirmacao(contador_seletor, acao, &sair, Textura_Popup,  Textura_Seletor_Botao, Textura_Texto_Confirmacao, Textura_BotaoS, Textura_BotaoN);
      }
  
  glDisable(GL_TEXTURE_2D);
  glDisable(GL_BLEND);

  glutSwapBuffers();

}

void seletorCena(){
  switch(MenuOn){
    case 0:
      desenhaCena();
    break;

    case 1:
      desenhaMenu();
    break;


  }

}


void redimensiona(int width, int height){

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, LARGURA_DO_MUNDO, 0, ALTURA_DO_MUNDO, -1, 1);

    float razaoAspectoJanela = ((float)width)/height;
    float razaoAspectoMundo = ((float) LARGURA_DO_MUNDO)/ ALTURA_DO_MUNDO;
    // se a janela está menos larga do que o mundo (16:9)...
    if (razaoAspectoJanela < razaoAspectoMundo) {
        // vamos colocar barras verticais (acima e abaixo)
        float hViewport = width / razaoAspectoMundo;
        float yViewport = (height - hViewport)/2;
        glViewport(0, yViewport, width, hViewport);
    }
    // se a janela está mais larga (achatada) do que o mundo (16:9)...
    else if (razaoAspectoJanela > razaoAspectoMundo) {
        // vamos colocar barras horizontais (esquerda e direita)
        float wViewport = ((float)height) * razaoAspectoMundo;
        float xViewport = (width - wViewport)/2;
        glViewport(xViewport, 0, wViewport, height);
    } else {
        glViewport(0, 0, width, height);
    }

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

}
//INICIALIZAÇÃO DOS OBJETOS
void initQuadrado(){
  //Para inicializar o quadrado somente uma vez. Podendo atualizar ele sem preocupações
  if (init==1){
    puloBackup(&pulo,&oldpulo); //Guarda o valor inicial de pulo
  init++;

  //Fundo:
  initAsFundo(&fundo1);
  tamQuadrado(&fundo1, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
  posQuadrado(&fundo1, 0, 0);
  texturaQuadrado(&fundo1, Textura_Fundo);
  linkQuadrado(&fundo1,&fundo2);

  initAsFundo(&fundo2);
  tamQuadrado(&fundo2, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
  posQuadrado(&fundo2, -LARGURA_DO_MUNDO + 1, 0);
  texturaQuadrado(&fundo2, Textura_Fundo2);
  linkQuadrado(&fundo2,&grama1);


  initAsFundo(&grama1);
  tamQuadrado(&grama1, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
  posQuadrado(&grama1, 0, ALTURA_DA_GRAMA);
  texturaQuadrado(&grama1, Textura_Grama);
  linkQuadrado(&grama1,&grama2);

  initAsFundo(&grama2);
  tamQuadrado(&grama2, LARGURA_DO_MUNDO,ALTURA_DO_MUNDO);
  posQuadrado(&grama2, LARGURA_DO_MUNDO, ALTURA_DA_GRAMA);
  texturaQuadrado(&grama2, Textura_Grama);
  linkQuadrado(&grama2,&q2);

  //Menu Inicial
  tamQuadrado(&logo, 60, 30);
  posQuadrado(&logo, (160-60)/2, 50);
  texturaQuadrado(&logo, Textura_Logo);

  tamQuadrado(&texto_iniciar, 15, 3);
  posQuadrado(&texto_iniciar, (160-15)/2, 30);
  texturaQuadrado(&texto_iniciar, Textura_Jogar);

  tamQuadrado(&texto_controles, 27, 3);
  posQuadrado(&texto_controles, (160-27)/2, 25);
  texturaQuadrado(&texto_controles, Textura_Controles);

  tamQuadrado(&texto_sair, 36, 3);
  posQuadrado(&texto_sair, (160-36)/2, 20);
  texturaQuadrado(&texto_sair, Textura_Texto_Sair);

  tamQuadrado(&seta, 5, 3);
  posQuadrado(&seta, (160-30)/2, 30);
  texturaQuadrado(&seta, Textura_Seletor);



  //Resto:
  initAsJogador(&q1); //TEMPORARIO
  tamQuadrado(&q1,TXPLAYER,TYPLAYER);
  posQuadrado(&q1,5,groundlevel);
  corQuadrado(&q1,.8,.1,.1);
  linkQuadrado(&q1,&q2);
  texturaQuadrado(&q1,Textura_Jogador1 );
  PropriedadesQuadrado(&q1, Textura_Jogador1, Textura_Jogador1_Roll, Textura_Jogador1_Pulo, Textura_Jogador1_Morte);
  reposicionaViewTextura(.83 , 1, 0, 1,&q1.animacao);

  nomeQuadrado(&q2,"q2");  //NÃO ESTA EM USO(SOMENTE PARA TESTES) (IDEIA NOMES LEGAIS ALEATORIOS PARA QUANDO MORRER APARECER --- ROGUE LEGACY)
  initAsInimigo(&q2);
  tamQuadrado(&q2,TXDEFAULT,TYDEFAULT);
  posQuadrado(&q2,180,groundlevel);
  corQuadrado(&q2,.1,.3,.9);
  linkQuadrado(&q2,&q3);
  texturaQuadrado(&q2, Textura_Fogueira1);

  nomeQuadrado(&q3,"q3");
  initAsInimigo(&q3);
  tamQuadrado(&q3,TXDEFAULT,TYDEFAULT);
  posQuadrado(&q3,-30,groundlevel);
  corQuadrado(&q3,.8,.5,.1);
  linkQuadrado(&q3,&q4);
  texturaQuadrado(&q3, Textura_Fogueira1);

  nomeQuadrado(&q4,"q4");
  initAsInimigo(&q4);
  tamQuadrado(&q4,TXDEFAULT,TYDEFAULT);
  posQuadrado(&q4,-30,groundlevel);
  corQuadrado(&q4,.8,.3,.9);
  linkQuadrado(&q4,&voador1);
  texturaQuadrado(&q4, Textura_Fogueira1);

  nomeQuadrado(&voador1,"voador1");
  initAsInimigo(&voador1);
  tamQuadrado(&voador1,TXDEFAULT,TYDEFAULT);
  posQuadrado(&voador1,-60,groundlevel+13);
  corQuadrado(&voador1,.8,.3,.9);
  linkQuadrado(&voador1,&moeda1);
  texturaQuadrado(&voador1, Textura_RolyPolyPreto);

  nomeQuadrado(&moeda1,"moeda1");
  initAsMoeda(&moeda1);
  tamQuadrado(&moeda1,TXMOEDA,TYMOEDA);
  posQuadrado(&moeda1,190,MOEDA_ALTURA);
  corQuadrado(&moeda1,.5,.6,.6);
  texturaQuadrado(&moeda1, Textura_MoedaGoldCoin);
  // linkQuadrado(&moeda1,&pw1);
   linkEnd(&moeda1);








  // nomeQuadrado(&pw1,"pw1");
  // initAsPowerUp(&pw1);
  // tamQuadrado(&pw1,TXMOEDA,TYMOEDA);
  // posQuadrado(&pw1,140,MOEDA_ALTURA);
  // // texturaQuadrado(&pw1, Textura_Fogueira1);
  // linkEnd(&pw1);


  }
}


void resetAll(){    //Da para colocar um variavel para avisar se volta em movimento ou nao
  theEnd = 0;
  glColor3f(1, 1, 1);
   // resetPulo();
   resetPulo(&pulo,&oldpulo,&PularOn);
   resetRolamento(&q1,Textura_Jogador1,TXPLAYER,TYPLAYER,&RolamentoOn,&RolamentoContadorFrames);
   init = 1;
    if (acao=='M')
      MovimentarOn=0;
    else
      MovimentarOn = 1;
   Score = 0;
   sair=0;
   PauseOn=0;
   ConfirmaOn=0;
   contador_seta=1;
   contador_seletor=1;
   glClear(GL_COLOR_BUFFER_BIT);
   inicializaTextura();
   initQuadrado();
   desenhaFundo();
   // //Com a textura buga.
   glutPostRedisplay();

   // glutTimerFunc(timer,atualiza,timer);
}

//KEYBOARD:
void keyboard(unsigned char key, int x, int y){
  if(PauseOn){
    switch (key){
      //Menu de Pause
      case 27: //Esc
        PauseOn=0;
        ConfirmaOn=0;
        verificarLiberarMovimento(&theEnd, &MovimentarOn, MenuOn);
      break;

       //
      case 13: //Enter

        switch(contador_seta){
          case 1:
            PauseOn = 0;
            verificarLiberarMovimento(&theEnd, &MovimentarOn, MenuOn);
          break;

          case 2:
            resetAll();
            break;
          break;

          case 3:
            ConfirmaOn=1;
            acao='M';
            printf("acao=%c\n", acao);
          break;

          case 4:
            ConfirmaOn=1;
            acao='S';
          break;

        }
        // if (contador_seta==1){
        // PauseOn=0;
        // verificarLiberarMovimento(&theEnd, &MovimentarOn);
        // }
        //
        // if (contador_seta==2){
        // resetAll();
        // break;
        //
        // }

        // if (contador_seta==3){
        // ConfirmaOn=1;
        // // acao='M';
        //
        // }
        //
        // if (contador_seta==4){
        // ConfirmaOn=1;
        // // acao='S';
        //
        // }

        //Menu de confirmacao
        
        if(ConfirmaOn==1 && contador_seletor==2){
          // sair=0;
          ConfirmaOn=0;
          contador_seletor=1;
          sair=0;
          break;
        }

        // if(ConfirmaOn==1 && contador_seletor==3){
        //   ConfirmaOn=0;
        //   contador_seletor=1;
        //   sair=0;
        //   resetAll();
        //   MenuOn=1;
        //   break;
        // }
        if (ConfirmaOn==1 && contador_seta==3)
          if (contador_seletor==1 && sair==1){
              case 'M':
                  contador_selecao=2;
                  resetAll();
                  MenuOn=1;
                  // glutPostRedisplay();
                  break;
            }

        if (ConfirmaOn==1 && contador_seta==4)
          if (contador_seletor==1 && sair==1){
            switch(acao){
            case 'S':
              exit(0);
            break;

            }
          }

      break;

      case 'w':
      case 'W':
        if(contador_seta==1)
            contador_seta=1;
        else
          contador_seta--;
      break;

      case 's':
      case 'S':
        if(contador_seta==4)
          contador_seta=4;
        else
          contador_seta++;
      break;

      case 'd':
      case 'D':
      if (ConfirmaOn==1){
        if(contador_seletor==2)
          contador_seletor=2;
        else
          contador_seletor++;
      }
    
      break;
    
      case 'a':
      case 'A':
      if (ConfirmaOn==1){
        if(contador_seletor==1)
          contador_seletor=1;
        else
          contador_seletor--;
      }
    
    }

  }

  if (MenuOn==1){
    switch(key){
      case 13: //Enter
        switch(contador_selecao){
          case 1:
            MenuOn=0;
            MovimentarOn=1;
          break;

          case 3:
          ConfirmaOn=1;
          acao='S';
          break;

        }

        // Confirmacao
        if (ConfirmaOn==1 && contador_selecao==3)
          if (contador_seletor==1 && sair==1){
            switch(acao){
            case 'S':
              exit(0);
            break;

            }
          }

        if(ConfirmaOn==1 && contador_seletor==2){
        // sair=0;
        ConfirmaOn=0;
        contador_seletor=1;
        sair=0;
        break;
        }

      case 'A':
      case 'a':
        // Confirmacao
        if (ConfirmaOn==1){
        if(contador_seletor==1)
          contador_seletor=1;
        else
          contador_seletor--;
        }
      break;

      case'd':
      case'D':
        if (ConfirmaOn==1){
        if(contador_seletor==2)
          contador_seletor=2;
        else
          contador_seletor++;
        }
      break;
      
      case 'w':
      case 'W':
        if(contador_selecao==1)
          contador_selecao=1;
        else
          contador_selecao--;
      break;

      case 's':
      case 'S':
        if(contador_selecao==3)
          contador_selecao=3;
        else
          contador_selecao++;
      break;

    }


  }
  else
  switch (key){
    case 27:
      PauseOn=1;
        if(MovimentarOn==1)
          verificarLiberarMovimento(&theEnd, &MovimentarOn, MenuOn);
        if(theEnd == 1)
          resetAll();


    // else if(PauseOn==1){
    //   PauseOn=0;
    //   ConfirmaOn=0;
    //   verificarLiberarMovimento(&theEnd, &MovimentarOn);
    // }
    break;


    // case 27:
    //   exit(0);
    //   break;

  //Pause (Desenvolvimento);
    case 'c':
    case 'C':
        verificarLiberarMovimento(&theEnd, &MovimentarOn, MenuOn);
    break;

    // //POPUP CONFIRMA
    //   case 'd':
    //   case 'D':
    //   if (ConfirmaOn==1){
    //     if(contador_seletor==2)
    //       contador_seletor=2;
    //     else
    //       contador_seletor++;
    //   }
    //
    //   break;
    //
    //   case 'a':
    //   case 'A':
    //   if (ConfirmaOn==1){
    //     if(contador_seletor==1)
    //       contador_seletor=1;
    //     else
    //       contador_seletor--;
    //   }
    //

  // // //Pause (Desenvolvimento);
  // //   case 'p':
  // //   case 'P':
  //   case 'c':
  //   case 'C':
  //       verificarLiberarMovimento(&theEnd, &MovimentarOn );
  //   break;

    // case 13: //Enter
      // if (PauseOn==1){
      //     if (contador_seta==1){
      //     PauseOn=0;
      //     verificarLiberarMovimento(&theEnd, &MovimentarOn);
      //     }
      //
      //     if (contador_seta==2){
      //     resetAll();
      //     break;
      //
      //     }
      //
      //     if (contador_seta==3){
      //     ConfirmaOn=1;
      //     // acao='M';
      //
      //     }
      //
      //     if (contador_seta==4){
      //     ConfirmaOn=1;
      //     // acao='S';
      //
      //     }
      //
      // }
      //
      // //Menu de confirmacao
      //   if(ConfirmaOn==1 && contador_seletor==2){
      //     // sair=0;
      //     ConfirmaOn=0;
      //     contador_seletor=1;
      //     sair=0;
      //     break;
      //     }
      //
      //
      //   if (ConfirmaOn==1 && contador_seta==4)
      //     if (contador_seletor==1 && sair==1){
      //       exit(0);
      //       break;
      //     }
      //
      //   break;

    //Reset em qualquer momento
    case 'r':
    case 'R':
      PauseOn = 1;
      contador_seta = 2;
      // ConfirmaOn=0;
      verificarLiberarMovimento(&theEnd, &MovimentarOn, MenuOn);
        // resetAll();
    break;

    //Pular
    case 32: //Barra de Espaço
    case 'w':
    case 'W':
    if(MovimentarOn){
      if(PularOn==0)
        PularOn=1;

      //Quando pula cancela o rolamento
      resetRolamento(&q1,Textura_Jogador1,TXPLAYER,TYPLAYER,&RolamentoOn,&RolamentoContadorFrames);

    }
  // PAUSE
    // if(PauseOn){
        // if(contador_seta==1)
        //     contador_seta=1;
        // else
        //   contador_seta--;
    // }

      break;

    //Rolamento:
    case 's':
    case 'S':
    case 25:
    if(MovimentarOn){
    // if(PularOn==0)
      if(RolamentoOn==0)
        RolamentoOn=1;
    }

  //PAUSE
    // if(PauseOn){
    // }
      // if(contador_seta==4)
      //   contador_seta=4;
      // else
      //   contador_seta++;


    break;


    ////////////////////////////////////////qq
    break;
    //Teste
    // case 'd':
    // resetRolamento(&q1,Textura_Jogador1,TXPLAYER,TYPLAYER,&RolamentoOn,&RolamentoContadorFrames);
    // break;

    default:
      break;


  }

}

//Para habilitar teclas consideradas especiais (Setinhas do Teclado)
void SpecialKeys(int key, int x, int y){
      switch (key)
  	{
  		case GLUT_KEY_LEFT:
  		// doSomething();
  			break;
  		case GLUT_KEY_RIGHT:
  		// doSomething();
  			break;
  		case GLUT_KEY_UP:
          if(MovimentarOn)
          {
            if(PularOn==0)
              PularOn=1;
            //Quando pula cancela o rolamento
            resetRolamento(&q1,Textura_Jogador1,TXPLAYER,TYPLAYER,&RolamentoOn,&RolamentoContadorFrames);

          }
  		  break;

      case GLUT_KEY_DOWN:
        if(MovimentarOn){
        // if(PularOn==0)
          if(RolamentoOn==0)
            RolamentoOn=1;
        }
  			break;
  	}
}


void inicializa(){
  glClearColor(.3,.3,.3,0);
  inicializaTextura();
  initQuadrado();
}

void chama_aumentaScore(int aumentaScoreTimer){
  if(theEnd==0)
    aumentaScore(&Score,MovimentarOn);
  glutTimerFunc(aumentaScoreTimer,chama_aumentaScore,aumentaScoreTimer);
}


void chama_mudaCorrida(int mudaCorridaTimer){
  mudaCorrida(&mudaCorridaTimer,&MIN_DIST_SPAWN,&MAX_RANDOM_SPAWN);
  glutTimerFunc(mudaCorridaTimer,chama_mudaCorrida,mudaCorridaTimer);
}




void Jogo(){

    //Callbacks
    // initQuadrado(); //Foi passado pra inicializa
    inicializa();
      // glutDisplayFunc(desenhaCena);







    glutDisplayFunc(seletorCena);
    glutReshapeFunc(redimensiona);
    glutTimerFunc(timerAnimacaoJogador,verificaTextura,timerAnimacaoJogador);
    glutSpecialFunc(SpecialKeys); //Outras Teclas(Setinhas do Teclado)
    glutKeyboardFunc(keyboard); //ASCII CODE
    glutTimerFunc(fpstimer,atualiza,fpstimer);
    // glutTimerFunc(6000,chama_mudaCorrida,6000); //Teste...
    glutTimerFunc(aumentaScoreTimer,chama_aumentaScore,aumentaScoreTimer);




  // else
  // main(1,"a");
    glutMainLoop();
}
