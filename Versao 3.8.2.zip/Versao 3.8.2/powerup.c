
//Verifica e identifica qual é o PowerUp
void verificaPowerUp(){


}










//Para encerrar o PowerUp apos um periodo de tempo.
//Se pa tem de ir na main, pq precisa chamar o q1 -> jogador
// void encerraPowerUp(){
//
//
//
//
// }
