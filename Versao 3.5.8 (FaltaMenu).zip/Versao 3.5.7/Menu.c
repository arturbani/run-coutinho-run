
#include "Bibliotecas/library.h"


#define ALTURA_DO_MUNDO 90
#define LARGURA_DO_MUNDO 160

#define ALTURA_DA_GRAMA  -10

int Enter = 0;

static int init=1;
static int contador_selecao=0;
static float aspect;
static int timer = 24;
static int MovimentarOn=1;
static float velocidade_g = .5;
static float velocidade_f = .1;


//Mudança nos nomes das Texturas
GLuint Textura_Fundo, Textura_Fundo2, Textura_Grama, Textura_Logo, Textura_Jogar, Textura_Controles, Textura_Seta;


quadrado fundo1, grama1, logo1;
quadrado fundo2, grama2;
quadrado jogar, controles, seta;


 void Menu_inicializa(){
    glClearColor(.9,.9,.9,0);

    Textura_Logo = SOIL_load_OGL_texture("texturas/Menu/logo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    Textura_Fundo = SOIL_load_OGL_texture("texturas/Menu/fundo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    Textura_Fundo2 = SOIL_load_OGL_texture("texturas/Menu/fundo2.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    Textura_Grama = SOIL_load_OGL_texture("texturas/Menu/grama.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    Textura_Jogar = SOIL_load_OGL_texture("texturas/Menu/jogar.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    Textura_Controles = SOIL_load_OGL_texture("texturas/Menu/controles.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    Textura_Seta = SOIL_load_OGL_texture("texturas/Menu/seta.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);

    if(Textura_Logo == 0){
        printf("[Texture loader] \"%s\" failed to load!\n", SOIL_last_result());
    }

}


 void Menu_reposiciona_g(quadrado * grama1, quadrado * grama2){
    if (grama1->x == -LARGURA_DO_MUNDO)
        grama1->x = LARGURA_DO_MUNDO;

    if (grama2->x == -LARGURA_DO_MUNDO)
        grama2->x = LARGURA_DO_MUNDO;

}

 void Menu_reposiciona_f(quadrado * fundo1, quadrado * fundo2){
    if (fundo1->x == LARGURA_DO_MUNDO)
        fundo1->x = -LARGURA_DO_MUNDO + 1;

    if (fundo2->x == LARGURA_DO_MUNDO)
        fundo2->x = -LARGURA_DO_MUNDO + 1;

}

 void Menu_reposiciona_seta(quadrado * seta){
    if (contador_selecao == 0){
        seta->x = (160-30)/2;
        seta->y = 30;
        }

    if (contador_selecao == 1){
        seta->x = (160-42)/2;
        seta->y = 25;
    }
    // if (contador_selecao == 2)
    //     seta->y =

}

 void Menu_movimenta(){
  fundo1.x+=velocidade_f;
  grama1.x-=velocidade_g;
  fundo2.x+=velocidade_f;
  grama2.x-=velocidade_g;

}

 void Menu_atualiza(int timer){
    //MovimentarOn para controlar se o movimento está ativo ou não
    if(Enter == 0)
    if (MovimentarOn==1)
        Menu_movimenta();

    glutPostRedisplay();
    // if(Enter == 0)
    glutTimerFunc(timer,Menu_atualiza,timer);

}

 void Menu_keyboard(unsigned char key, int x, int y){

    switch (key){
        case 27: //ESC
            exit(0);
            break;

        case 119:
        // if(Enter == 0)
            if (contador_selecao>0){
                contador_selecao--;
                printf("Contador: %d\n", contador_selecao);
                glutPostRedisplay();
            }

            break;

        case 115:
        // if(Enter == 0)
            if (contador_selecao<2){
                contador_selecao++;
                printf("Contador: %d\n", contador_selecao);
                glutPostRedisplay();
            }

            break;

        case 13:
          // Enter++;
           Enter = contador_selecao+1;
           Menu();
          // printf("%i\n",Enter);
        break;


    default:
        break;


  }

}


 void Menu_SpecialKeys(int key, int x, int y){
      switch (key)
  	{
  		case GLUT_KEY_LEFT:
  		// doSomething();
  			break;
  		case GLUT_KEY_RIGHT:
  		// doSomething();
  			break;
  		case GLUT_KEY_UP:
        if (contador_selecao>0){
            contador_selecao--;
            printf("Contador: %d\n", contador_selecao);
            glutPostRedisplay();
        }
  		  break;

      case GLUT_KEY_DOWN:
        if (contador_selecao<2){
            contador_selecao++;
            printf("Contador: %d\n", contador_selecao);
            glutPostRedisplay();
        }
  			break;
  	}
}



 void Menu_desenhaTelaInicial(){
    glColor4f(1, 0, 1, 1);
    glBegin(GL_POLYGON);
        glVertex3f(20, 0*aspect, 1);
        glVertex3f(80*aspect, 0*aspect, 1);
        glVertex3f(80*aspect, 20*aspect, 1);
        glVertex3f(0*aspect, 80*aspect, 1);
    glEnd();

}

 void Menu_desenhaQuadrado(quadrado* a){


  glBindTexture(GL_TEXTURE_2D, a->textura);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

  glBegin(GL_TRIANGLE_FAN);
      glTexCoord2f(0, 0); glVertex3f(a->x, a->y,  0)  ;
      glTexCoord2f(1, 0); glVertex3f(a->x + a->tx, a->y,  0);
      glTexCoord2f(1, 1); glVertex3f(a->x + a->tx, a->y + a->ty,  0);
      glTexCoord2f(0, 1); glVertex3f(a->x, a->y + a->ty,  0);
  glEnd();

}

 void Menu_desenhaCena(){

    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    Menu_reposiciona_f(&fundo1, &fundo2);
    Menu_reposiciona_g(&grama1, &grama2);
    Menu_reposiciona_seta(&seta);

    Menu_desenhaQuadrado(&fundo1);
    Menu_desenhaQuadrado(&fundo2);
    Menu_desenhaQuadrado(&grama1);
    Menu_desenhaQuadrado(&grama2);
    Menu_desenhaQuadrado(&logo1);
    Menu_desenhaQuadrado(&jogar);
    Menu_desenhaQuadrado(&controles);
    Menu_desenhaQuadrado(&seta);
    // desenhaTelaInicial();

    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
    glutSwapBuffers();

}

 void Menu_initQuadrado(){
  //Para inicializar o quadrado somente uma vez. Podendo atualizar ele sem preocupações
  if (init==1){
        init++;
        tamQuadrado(&fundo1, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
        posQuadrado(&fundo1, 0, 0);
        texturaQuadrado(&fundo1, Textura_Fundo);

        tamQuadrado(&fundo2, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
        posQuadrado(&fundo2, -LARGURA_DO_MUNDO + 1, 0);
        texturaQuadrado(&fundo2, Textura_Fundo2);

        tamQuadrado(&grama1, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
        posQuadrado(&grama1, 0, ALTURA_DA_GRAMA);
        texturaQuadrado(&grama1, Textura_Grama);

        tamQuadrado(&grama2, LARGURA_DO_MUNDO, ALTURA_DO_MUNDO);
        posQuadrado(&grama2, LARGURA_DO_MUNDO, ALTURA_DA_GRAMA);
        texturaQuadrado(&grama2, Textura_Grama);

        tamQuadrado(&logo1, 60, 30);
        posQuadrado(&logo1, (160-60)/2, 50);
        texturaQuadrado(&logo1, Textura_Logo);

        tamQuadrado(&jogar, 15, 3);
        posQuadrado(&jogar, (160-15)/2, 30);
        texturaQuadrado(&jogar, Textura_Jogar);

        tamQuadrado(&controles, 27, 3);
        posQuadrado(&controles, (160-27)/2, 25);
        texturaQuadrado(&controles, Textura_Controles);

        tamQuadrado(&seta, 5, 3);
        posQuadrado(&seta, (160-30)/2, 30);
        texturaQuadrado(&seta, Textura_Seta);

    }
}

 void Menu_redimensiona(int width, int height){

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, LARGURA_DO_MUNDO, 0, ALTURA_DO_MUNDO, -1, 1);

    float razaoAspectoJanela = ((float)width)/height;
    float razaoAspectoMundo = ((float) LARGURA_DO_MUNDO)/ ALTURA_DO_MUNDO;
    // se a janela está menos larga do que o mundo (16:9)...
    if (razaoAspectoJanela < razaoAspectoMundo) {
        // vamos colocar barras verticais (acima e abaixo)
        float hViewport = width / razaoAspectoMundo;
        float yViewport = (height - hViewport)/2;
        glViewport(0, yViewport, width, hViewport);
    }
    // se a janela está mais larga (achatada) do que o mundo (16:9)...
    else if (razaoAspectoJanela > razaoAspectoMundo) {
        // vamos colocar barras horizontais (esquerda e direita)
        float wViewport = ((float)height) * razaoAspectoMundo;
        float xViewport = (width - wViewport)/2;
        glViewport(xViewport, 0, wViewport, height);
    } else {
        glViewport(0, 0, width, height);
    }

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

}


int Menu(){

if(Enter==0){
    Menu_inicializa();
    //Callbacks
    Menu_initQuadrado();
    glutDisplayFunc(Menu_desenhaCena);
    glutReshapeFunc(Menu_redimensiona);

    printf("INICIM:%i\n",Enter);
    glutKeyboardFunc(Menu_keyboard);
    glutSpecialFunc(Menu_SpecialKeys);

    glutTimerFunc(timer,Menu_atualiza,timer);
}

else{
  if(Enter == 1)
  Enter = 0;
  Jogo();

  // exit(0);
  // glutDisplayFunc(Menu_desenhaCena);
  // printf("SaiuDOLOOP\n");
  //     return Enter;
}
// glutMainLoop();
}
