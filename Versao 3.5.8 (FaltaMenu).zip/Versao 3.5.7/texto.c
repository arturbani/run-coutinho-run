#include "Bibliotecas/library.h"

void texto(void * font, char *s, float x, float y) {
    int i;
    glRasterPos2f(x, y);

    for (i = 0; i < strlen(s); i++) {
        glutBitmapCharacter(font, s[i]);
    }
}


char *my_itoa(int num, char *str){
        if(str == NULL)
          return NULL;

        sprintf(str, "%d", num);
        return str;
}

void mostraScore(int score){

    char stringScore[50];
    my_itoa(score, stringScore);
    float x=150, y=85;
    //printf("String %s\n", stringScore);

    // if (x>=10000){
    //   x-=5;
    // }
    glColor4f(1, 0, 0, 1);
    texto(GLUT_BITMAP_HELVETICA_18, stringScore , x, y);
    glColor4f(1, 1, 1, 1);
    // glutSwapBuffers();

  }

void telaFim(){
// glColor4f(1, 1, 0, .1);

// glBegin(GL_TRIANGLE_FAN);

//   glVertex2d(0, 0);
//   glVertex2d(0, 30);
//   glVertex2d(30, 30);
//   glVertex2d(30, 0);

// glEnd();

glColor3f(0, 0, 0);
texto(GLUT_BITMAP_HELVETICA_18, "PERDEU OTARIO!", 25, 50);

}

//Depois Mudar de Lugar(Temporário);
void GameOver(int* MovimentarOn,int *theEnd){
  *MovimentarOn = 0;
  *theEnd = 1;

  // telaFim();

glutPostRedisplay();
  // glColor3f(1, 1, 1);

}
