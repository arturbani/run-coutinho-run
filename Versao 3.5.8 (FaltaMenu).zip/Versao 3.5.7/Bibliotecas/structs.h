// #include "animacao.h"
#include <GL/freeglut.h>

//animacao header (.h)
typedef struct Textura_Animacao{

  float X_Inicio_Textura,X_Final_Textura,Y_Inicio_Textura,Y_Final_Textura;
  int Contador;


}textura_animacao;

typedef struct propriedades_jogador {

  int InvencibilidadeOn;
  // int AllowDoubleJump
  // int DiminuirTempo;

  GLuint rolamento;
  GLuint pulo;
  GLuint morte;
  GLuint backup;

}Propriedades_Jogador;


//Structs_Functions header (.h)
typedef struct Quadrado{
  //Atributos Base: Servem para qualquer Quadrado:
    char nome [30];
    float x;
    float y;
    float tx;
    float ty;
    GLuint textura;
    textura_animacao animacao ;
    Propriedades_Jogador jogador;
    float r,g,b; //Cores
    struct Quadrado *proxquadrado;

  //Atributos Específicos: Para cada 'subclasse': (Obs:Cada subclasse possui sua propria library)
  //Moedas:
    int isMoeda; //Identidade (se é moeda ou não)

  //Inimigos:
    int isInimigo; //Identidade

    int isJogador;

  //Fundo:
    int isFundo;

  //PowerUp - 1:Invencilibidade 2:?
    int isPowerUp;


    int visivel;   //Pode Desenhar
    int colidivel; //Pode Colidir


}quadrado;
