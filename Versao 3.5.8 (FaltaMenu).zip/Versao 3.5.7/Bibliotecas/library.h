#include <GL/glew.h>
#include <GL/glut.h>
#include <GL/freeglut.h>
#include <SOIL/SOIL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "structs.h"
#include "structs_functions.h"
#include "texto.h"
//#include "fimdejogo.h" //OBS:Precisa vir depois do texto.h necessariamente
#include "mecanicas.h" //Mudar depois
#include "animacao.h"
#include "powerup.h"
#include "Menu.h"
#include "Jogo.h"
#include "Main.h"
